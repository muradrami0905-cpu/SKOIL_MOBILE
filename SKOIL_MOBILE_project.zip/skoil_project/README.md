# SKOIL MOBILE — Android project starter

This is a real project scaffold, not an APK. The requested full open-world game is far beyond a single instant build; this folder starts the Android app shell and documents the planned modules.

## Target
- Android, landscape
- Modes: STORY MODE and MULTIPLAYER only
- Main character: Sky
- Target device: Honor X7

## Build note
An Android SDK/Gradle toolchain and game assets/engine are required to produce an installable APK. They are not available in this execution environment, so no APK is claimed here.
