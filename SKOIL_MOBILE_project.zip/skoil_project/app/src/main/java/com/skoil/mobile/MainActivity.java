package com.skoil.mobile;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Color;
import android.view.View;

public class MainActivity extends Activity {
  @Override public void onCreate(Bundle state) { super.onCreate(state); getWindow().getDecorView().setSystemUiVisibility(5894|1024|512); setContentView(new SkoilScreen()); }
  static class SkoilScreen extends View {
    Paint p = new Paint(3);
    SkoilScreen(Activity a){super(a);}
    @Override protected void onDraw(Canvas c){
      float w=getWidth(),h=getHeight();
      c.drawColor(Color.rgb(10,22,28));
      p.setShader(new android.graphics.LinearGradient(0,0,0,h,Color.rgb(85,143,159),Color.rgb(19,48,39),android.graphics.Shader.TileMode.CLAMP));c.drawRect(0,0,w,h,p);p.setShader(null);
      p.setColor(Color.rgb(50,91,69)); c.drawOval(-w*.15f,h*.42f,w*.42f,h*.9f,p);c.drawOval(w*.55f,h*.36f,w*1.2f,h*.9f,p);
      p.setColor(Color.rgb(20,43,34)); c.drawRect(0,h*.73f,w,h,p);
      p.setColor(Color.WHITE);p.setTextSize(h*.075f);p.setFakeBoldText(true);c.drawText("SKOIL",w*.07f,h*.17f,p);
      p.setTextSize(h*.025f);p.setFakeBoldText(false);p.setColor(Color.rgb(194,218,211));c.drawText("MOBILE  •  WORLD PROJECT",w*.073f,h*.22f,p);
      p.setColor(Color.rgb(226,235,229));p.setTextSize(h*.045f);c.drawText("STORY MODE",w*.08f,h*.55f,p);c.drawText("MULTIPLAYER",w*.08f,h*.64f,p);
      p.setColor(Color.rgb(180,210,195));p.setTextSize(h*.022f);c.drawText("PROJECT SHELL — GAME CONTENT IN DEVELOPMENT",w*.08f,h*.91f,p);
    }
  }
}
